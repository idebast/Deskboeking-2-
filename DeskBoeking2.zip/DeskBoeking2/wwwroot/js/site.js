﻿// Please see documentation at https://docs.microsoft.com/aspnet/core/client-side/bundling-and-minification
// for details on configuring this project to bundle and minify static web assets.

// Write your JavaScript code.

$('#deskid').on('click', function () {
    //alert($(this).find("option:selected").text());
    //console.log($(this).val());
});

function AvailableDesks(d) {
    $.ajax({
        url: 'Boeking/AvailableDesks',
        data: { date: d }
    }).done(function () {
        alert('Added');
    });
}

// set day to today
$(document).ready(function () {
    let today = new Date().toISOString().slice(0, 10);
    $('#dp').val(today); // FIXME: resets the date to today when refreshing part of the page
 //   AvailableDesks(today);
});

$('#dp').on('change', function () {
    var x = document.getElementById("dp").value;
    //alert(x);
    AvailableDesks(x);
});

$('#btn_book').on('click', function () {
    var t = document.getElementById("dp").value;
    var d = $("#deskid").find("option:selected").text();
    var s = "Booked desk " + d + " on " + t;
    alert(s);
    //console.log(s);
});
