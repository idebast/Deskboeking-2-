﻿using DeskBoeking2.Data;
using System.Collections;

namespace DeskBoeking2.Models
{
    public class SQLDeskRepository : IDeskRepository
    {
        private readonly DeskBoeking2DbContext context;

        public SQLDeskRepository(DeskBoeking2DbContext context)
        {
            this.context = context;
        }

        public Desk Add(Desk desk)
        {
            context.Desks.Add(desk);
            context.SaveChanges();
            return desk;
        }

        public Desk Delete(int Id)
        {
            Desk desk = context.Desks.Find(Id);
            if (desk == null)
            {
                context.Desks.Remove(desk);
                context.SaveChanges();
            }
            return desk;
        }

        public List<Desk> GetAllDesks()
        {
            return context.Desks.ToList();
        }

        public Desk GetDesk(int Id)
        {
            return context.Desks.Find(Id);
        }

        public Desk Update(Desk deskChanges)
        {
            var desk = context.Desks.Attach(deskChanges);
            desk.State = Microsoft.EntityFrameworkCore.EntityState.Modified;
            context.SaveChanges();
            return deskChanges;
        }
    }
}
