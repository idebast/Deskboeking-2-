﻿using Microsoft.Extensions.Localization;
using System.Reflection;

using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DeskBoeking2.Models
{
    public class LanguageService
    {
        private readonly IStringLocalizer _localizer;

        public LanguageService(IStringLocalizerFactory factory)
        {
            var type = typeof(ShareResource);
            var assemblyName = new AssemblyName(type.GetTypeInfo().Assembly.FullName);
            _localizer = factory.Create("SharedResource", assemblyName.Name);
        }

        public LocalizedString Getkey(string key)
        {
            return _localizer[key];
        }

    }
}
