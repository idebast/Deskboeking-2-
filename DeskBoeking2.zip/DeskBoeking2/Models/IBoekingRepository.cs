﻿namespace DeskBoeking2.Models
{
    public interface IBoekingRepository
    {
    }
}
