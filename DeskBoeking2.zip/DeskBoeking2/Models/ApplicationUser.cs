﻿using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using System.ComponentModel.DataAnnotations.Schema;

namespace DeskBoeking2.Models
{
    public class ApplicationUser : IdentityUser
    {
        [PersonalData]
        [Column(TypeName = "nvarchar(50)")]
        public string? Taal { get; set; }

        [PersonalData]
        [Column(TypeName = "nvarchar(50)")]
        public string? StamNummer { get; set; } // om te bepalen of iemand access heeft tot bepaalde zone/plaats/gebouw

        [PersonalData]
        [Column(TypeName = "nvarchar(50)")]
        public string? Team { get; set; } // team of departement

        // navigation property
        public virtual ICollection<Boeking> Boekingen { get; set; }

    }
}

