﻿using System.Collections;

namespace DeskBoeking2.Models
{
    public interface IDeskRepository
    {
        Desk Add(Desk desk);
        Desk Delete(int Id);
        Desk Update(Desk desk);

        Desk GetDesk(int Id);
        List<Desk> GetAllDesks();
    }
}
