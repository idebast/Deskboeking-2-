﻿using DeskBoeking2.Data;
using System.Collections;

namespace DeskBoeking2.Models
{
    public class MockDeskRepository : IDeskRepository
    {
        private List<Desk> _desks;

        public MockDeskRepository()
        {
            _desks = new List<Desk>() {
                new Desk
                {
                DeskId = 1,
                Naam = "BuildingB_5_A1",
                GrondplanImgUrl = "/img/BuildingA_5_A1.jpg",
                Grondplan = Array.Empty<byte>(),
                Faciliteiten = "Geen docking station, 1 scherm"
                },
                new Desk
                {
                    DeskId = 2,
                    Naam = "BuildingB_5_A2",
                    GrondplanImgUrl = "/img/BuildingA_5_A2.jpg",
                    Grondplan = Array.Empty<byte>(),
                    Faciliteiten = "Lenovo, 1 scherm"
                },
                new Desk
                {
                    DeskId = 3,
                    Naam = "BuildingB_5_A3",
                    GrondplanImgUrl = "/img/BuildingA_5_A3.jpg",
                    Grondplan = Array.Empty<byte>(),
                    Faciliteiten = "Lenovo, 1 scherm"
                },
                new Desk
                {
                    DeskId = 4,
                    Naam = "BuildingB_5_A4",
                    GrondplanImgUrl = "/img/BuildingA_5_A4.jpg",
                    Grondplan = Array.Empty<byte>(),
                    Faciliteiten = "Lenovo, 1 scherm"
                }
                };
        }

        public Desk GetDesk(int Id)
        {
            return _desks.FirstOrDefault(d => d.DeskId == Id);
        }

        public Desk Add(Desk desk)
        {
            desk.DeskId = _desks.Max(e => e.DeskId)+1;
            _desks.Add(desk);
            return desk;
        }

        public Desk Delete(int Id)
        {
            Desk desk = _desks.FirstOrDefault(e => e.DeskId == Id);
            if (desk != null)
            {
                _desks.Remove(desk);
            }
            return desk;
        }

        public Desk Update(Desk deskChanges)
        {
            Desk desk = _desks.FirstOrDefault(e => e.DeskId == deskChanges.DeskId);
            if (desk != null)
            {
                desk.Grondplan = deskChanges.Grondplan;
                desk.Naam = deskChanges.Naam;
                desk.Faciliteiten = deskChanges.Faciliteiten;
                desk.GrondplanImgUrl = deskChanges.GrondplanImgUrl;
            }
            return desk;
        }

        public List<Desk> GetAllDesks()
        {
            return _desks;
        }
    }
}
