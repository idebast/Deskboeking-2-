﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DeskBoeking2.Models
{
    public class Boeking
    {
        [Key]
        public int BoekingId { get; set; }

        [ForeignKey("ApplicationUser")]
        public string UserId { get; set; } //FK to ApplicationUser
        public ApplicationUser ApplicationUser { get; set; }

        [ForeignKey("Desk")]
        public int DeskId { get; set; } // FK to Desks
        public Desk Desk { get; set; }

        public DateTime Datum { get; set; }

        // navigation property
        public virtual ICollection<Desk> Desks { get; set; }

    }
}
