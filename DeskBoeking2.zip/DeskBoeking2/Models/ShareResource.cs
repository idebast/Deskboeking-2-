﻿namespace DeskBoeking2.Models
{
    public class ShareResource
    {
    }
}
