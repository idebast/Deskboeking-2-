﻿using System.ComponentModel.DataAnnotations;

namespace DeskBoeking2.Models
{
    public class Desk
    {
        [Key]
        public int DeskId { get; set; }

        public string Naam { get; set; }

        public byte[] Grondplan { get; set; }

        public string GrondplanImgUrl { get; set; }
        
        public string Faciliteiten { get; set; }
    }
}
