﻿using DeskBoeking2.Data;
using DeskBoeking2.Models;
using DeskBoeking2.ViewModels;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;

namespace DeskBoeking2.Controllers
{
    public class BoekingController : Controller
    {
        //private readonly DeskBoeking2DbContext _context;

        //public BoekingController(DeskBoeking2DbContext context)
        //{
        //    _context = context;
        //}

        //private readonly DeskBoeking2DbContext _context;
        private readonly IDeskRepository _deskRepository;

        public BoekingController(IDeskRepository deskRepository)
        {
            _deskRepository = deskRepository;
        }

        public IActionResult Index()
        {
            //Desk model = _deskRepository.GetDesk(1);

            //ViewData["Desk"] = model;
            //ViewData["PageTitle"] = "Lalalal";

            //List<Desk> model = _deskRepository.GetAllDesks();

            //ViewData["Desk"] = model;
            //ViewData["PageTitle"] = "alle desks";

            BoekingIndexViewModel boekingIndexViewModel = new BoekingIndexViewModel()
            {
                DeskList = _deskRepository.GetAllDesks(),
            };

            return View(boekingIndexViewModel);
        }


        public PartialViewResult Desks()
        {

            Desk model = _deskRepository.GetDesk(1);

            ViewData["Desk"] = model;

            return PartialView("_FreeDesks", model);
        }
    }
}
