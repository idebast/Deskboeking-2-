﻿using DeskBoeking2.Models;

namespace DeskBoeking2.ViewModels
{
    public class BoekingIndexViewModel
    {
        public List<Desk> DeskList { get; set; }
    }
}

