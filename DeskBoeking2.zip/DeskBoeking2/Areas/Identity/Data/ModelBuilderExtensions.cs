﻿using DeskBoeking2.Models;
using Microsoft.EntityFrameworkCore;

namespace DeskBoeking2.Data
{
    public static class ModelBuilderExtensions
    {
        public static void Seed(this ModelBuilder builder)
        {
            // seeder
            builder.Entity<Desk>().HasData(
                new Desk
                {
                    DeskId = 1,
                    Naam = "BuildingB_5_A1",
                    GrondplanImgUrl = "/img/BuildingA_5_A1.jpg",
                    Grondplan = Array.Empty<byte>(),
                    Faciliteiten = "Geen docking station, 1 scherm"
                },
                new Desk
                {
                    DeskId = 2,
                    Naam = "BuildingB_5_A2",
                    GrondplanImgUrl = "/img/BuildingA_5_A2.jpg",
                    Grondplan = Array.Empty<byte>(),
                    Faciliteiten = "Lenovo, 1 scherm"
                },
                new Desk
                {
                    DeskId = 3,
                    Naam = "BuildingB_5_A3",
                    GrondplanImgUrl = "/img/BuildingA_5_A3.jpg",
                    Grondplan = Array.Empty<byte>(),
                    Faciliteiten = "Lenovo, 1 scherm"
                },
                new Desk
                {
                    DeskId = 4,
                    Naam = "BuildingB_5_A4",
                    GrondplanImgUrl = "/img/BuildingA_5_A4.jpg",
                    Grondplan = Array.Empty<byte>(),
                    Faciliteiten = "Lenovo, 1 scherm"
                }
                );
        }
    }
}
