﻿using DeskBoeking2.Models;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;

namespace DeskBoeking2.Data;

public class DeskBoeking2DbContext : IdentityDbContext<ApplicationUser>
{
    public DeskBoeking2DbContext(DbContextOptions<DeskBoeking2DbContext> options)
        : base(options)
    {
    }

    public DbSet<Boeking> Boekingen { get; set; }

    public DbSet<Desk> Desks { get; set; }

    protected override void OnModelCreating(ModelBuilder builder)
    {
        builder.Seed();

        base.OnModelCreating(builder);
        // Customize the ASP.NET Identity model and override the defaults if needed.
        // For example, you can rename the ASP.NET Identity table names and more.
        // Add your customizations after calling base.OnModelCreating(builder);
    }

}
