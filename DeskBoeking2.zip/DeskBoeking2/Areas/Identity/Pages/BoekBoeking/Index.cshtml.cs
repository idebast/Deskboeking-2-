using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace DeskBoeking2.Areas.Identity.Pages.Boeking
{
    public class IndexModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
